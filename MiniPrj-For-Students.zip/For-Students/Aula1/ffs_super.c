#include <stdio.h>
#include <string.h>
#include <math.h>

#ifndef DISK_DRIVER_H
#include "disk_driver.h"
extern struct disk_operations disk_ops;
#endif

#ifndef FFS_SUPER_H
#include "ffs_super.h"
#endif

#ifndef FFS_INODE_H
#include "ffs_inode.h"
#endif


struct IMsuper ffs_IMsb; // one in-memory SB only

/***
  create: To be called by format(), requires NOT mounted as it
          overwrites the in-memory SB structure.
	  DOES NOT UPDATE the disk superblock, that must be an explicit
	  call to the disk driver write
    parameters:
     @in: disk size (blocks); number of blocks to allocate for inodes
     @out: pointer to superblock structure				***/

static void super_create(unsigned int nblocks, unsigned int ninodeblocks) {
  ffs_IMsb.sb.fsmagic= FS_MAGIC;

  /*** TODO ***/

  ffs_IMsb.sb.mounted= 0;
}


/***
  read: reads in a SB from disk, overwrites the in-mem SB structure.
	Requires disk open at the driver level.
    parameters:
     @out: pointer to superblock structure				***/

static int super_read() {
  int ercode;
  union sb_block sb_u;

  ercode=disk_ops.read(/*** TODO ***/);
  if (ercode < 0) return ercode;

  memcpy(&ffs_IMsb.sb, /*** TODO ***/, /*** TODO ***/);

  return 0;
}


/***
  write: writes the in-mem SB structure to disk.
        Requires disk open at the driver level.
    parameters:
     @in: pointer to superblock structure				***/

static int super_write() {
  int ercode;
  union sb_block sb_u;

  memset(sb_u.data, 0, DISK_BLOCK_SIZE);	// clean...
  memcpy(&sb_u.sb, )/*** TODO ***/, /*** TODO ***/);

  ercode=disk_ops./*** TODO ***/(/*** TODO ***/, /*** TODO ***/);
  if (ercode < 0) return ercode;

  return 0;
}


/***
  get*: gets the relevant BFS info from the in-mem SB
    parameters: none
    returns: unsigned int value or address of region			***/

unsigned int super_getStartRotdir() {
  return /*** TODO ***/;
}

unsigned int super_getStartDtBmap() {
  return /*** TODO ***/;
}

unsigned int super_getStartDtArea() {
  return /*** TODO ***/;
}

unsigned int super_getNinodeblocks() {
  return /*** TODO ***/;
}

unsigned int super_getTotalInodes() {
  return /*** TODO ***/;
}

unsigned int super_getNdatablocks() {
  return /*** TODO ***/;
}


/* Helper functions */

void super_debug() {
  printf("Superblock:\n");
  printf("  fsmagic          = 0x%x\n", /*** TODO ***/);
  printf("  nblocks          = %u\n", /*** TODO ***/);
  printf("  nbmapblocksinodes= %u\n", /*** TODO ***/);
  printf("  ninodeblocks     = %u\n", /*** TODO ***/);
  printf("  ninodes          = %u\n", /*** TODO ***/);
  printf("  nbmapblocksdata  = %u\n", /*** TODO ***/);
  printf("  ndatablocks      = %u\n", /*** TODO ***/);
  printf("  startInArea      = %u\n", /*** TODO ***/);
  printf("  startRotdir      = %u\n", /*** TODO ***/);
  printf("  startDtBmap      = %u\n", /*** TODO ***/);
  printf("  startDtArea      = %u\n", /*** TODO ***/);
  printf("  mounted          = %s\n", (ffs_IMsb.sb.mounted)?"yes":"no");
  fflush(stdout);
}

void IMsuper_debug() {
  printf("In-Memory Superblock:\n");
  printf("  dirty       = %s\n", (ffs_IMsb.dirty)?"yes":"no");
  super_debug();
}


struct super_operations super_ops= {
	.create= &super_create,
	.read= &super_read,
	.write= &super_write,
	.getStartRotdir= &super_getStartRotdir,
	.getStartDtBmap= &super_getStartDtBmap,
	.getStartDtArea= &super_getStartDtArea,
	.getNinodeblocks= &super_getNinodeblocks,
	.getTotalInodes= &super_getTotalInodes,
	.getNdatablocks= &super_getNdatablocks
};
